import pip

def install(selenium):
    pip.main(['install', selenium])
def install(smtplib):
    pip.main(['install', smtplib])	
def install(openpyxl):
    pip.main(['install', openpyxl])	
def install(config):
    pip.main(['install', config])	
def install(datetime):
    pip.main(['install', datetime])	
from datetime import datetime
import smtplib
from selenium import webdriver
from openpyxl import load_workbook
import config_script_check as config


def get_data_from_file():
    ''' Returns old value of titles and descriptions from Excel file '''
    print('Reading the input data from the Excel file')
    wb = load_workbook(config.EXCEL_FILE)
    ws = wb.worksheets[0]

    old_values = []
    for row in ws.rows:
        # [link, title, description]
        old_value = [row[0].value, row[1].value, row[2].value]
        old_values.append(old_value)
    return old_values


def get_new_data(links):
    ''' Returns titles and descriptions from parsed HTML'''
    print('Start browser to open the page')
    driver = webdriver.Chrome()

    new_data = []
    for count, link in enumerate(links):
        # [link, title, description]
        driver.get(link[0])
        title = driver.title
        description = driver.find_element_by_xpath(
            '//meta[@name="description"]').get_attribute('content')
        new_data.append([link[0], title, description])
        print('Websites: {}/{}'.format(count+1, len(links)), end='\r')
    driver.quit()
    return new_data


def compare_data(old_data, new_data):
    ''' Compares old data with new '''
    print('Compare data')
    wrong_data = []
    for count, nd in enumerate(new_data):
        if nd[1] != old_data[count][1] and nd[2] != old_data[count][2]:
            wrong_data.append([nd[0], nd[1], nd[2]])
        elif nd[1] != old_data[count][1]:
            wrong_data.append([nd[0], nd[1], ''])
        elif nd[2] != old_data[count][2]:
            wrong_data.append([nd[0], '', nd[2]])
    return wrong_data
 
def save_data(rows):
    ''' Saves data into Excel file '''
    print('Save data')
    wb = load_workbook(config.EXCEL_FILE)
    date = datetime.now()
    ws_title = date.strftime('%m-%d-%Y')
    ws = wb.create_sheet(ws_title)

    for row_nr, row in enumerate(rows):
        for col_nr, val in enumerate(row):
            _ = ws.cell(column=col_nr+1, row=row_nr+1, value=val)
    wb.save(config.EXCEL_FILE)


def send_email(data):
    ''' Sends email '''
    print('send email')
    # Settings email
    email_from = config.EMAIL_FROM
    email_to = config.EMAIL_TO
    password = config.EMAIL_PASSWORD
    server = smtplib.SMTP(config.EMAIL_SERVER, config.EMAIL_PORT)

    # Create message
    msg = 'Hi great OS team! \n\n' 'You are receiving this alert, because the meta data (title or meta description) for some of your Vistaprint pages has changed. \n\n' 'See the summary below. \n\n' 'The input file (URLs checked, page titles, meta descriptions) is saved here along with the output (new values) \n: G:\Organic Search\Compatibility\Scripts files\input.xlsx \n\n' 'Look at the last spreadsheet on the right with the date recorded \n\n' #\n is the new line character in Python. It is used inside a string
	# the msg variable contains the message
    for count, d in enumerate(data):
        msg += '{}. {}\n'.format(count+1, d[0])
        if d[1]:
            msg += 'New Title: {}\n'.format(d[1])
        if d[2]:
            msg += 'New Description: {}\n'.format(d[2])
        msg += '\n'
        
		
    message = '\r\n'.join([
        'From:' + email_from,
        'To:' + email_to,
        'Subject: Alert - Changed Page Title or Meta Description\n\n',
        msg
    ])
    server.starttls() #this is a security function, needed to connected to the gmail server. It protects the email password.
    server.login(email_from, password)
    server.sendmail(email_from, [email_to], message)
	#this line sends the message
    server.quit()


if __name__ == '__main__':
    old_values = get_data_from_file()
    new_values = get_new_data(old_values)
    wrong_data = compare_data(old_values, new_values)

    if wrong_data:
        save_data(wrong_data)
        send_email(wrong_data)
#missing part - print the file location in the email and link to Vistawiki