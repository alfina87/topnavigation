# EXCEL_FILE = 'input.xlsx' # this is only in the Excel file is placed in the same folder as the Python script 
EXCEL_FILE = 'G:\\Organic Search\\Compatibility\\filescripts\\input.xlsx' 

EMAIL_FROM = 'anivistaprint1@gmail.com'
EMAIL_PASSWORD = 'sdfghj123'
EMAIL_SERVER = 'smtp.gmail.com'
EMAIL_PORT = 587

EMAIL_TO = 'avalentinova@vistaprint.com'

#to send the email, we use the parameters of the Gmail server. First, we specify the server location (or its IP) and then the port to use. If the email is from another service, then we should find the corresponding info.
# to send the email from gmail, allow less secure apps on the Gmail account https://www.google.com/settings/security/lesssecureapps - TURN ON